package com.banglalink.rso06;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.view.WindowInsets;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;

public class MainActivity extends Activity {
  private WebView web;
  private int topPaddingPx = 0;
  private ValueCallback<Uri[]> fileChooserCallback;
  private static final int FILE_CHOOSER_REQUEST = 1001;

  private void applyTopSpacing() {
    if (web == null) return;
    final int px = topPaddingPx;
    web.evaluateJavascript("(function(){document.body.style.paddingTop='" + px + "px';document.documentElement.style.setProperty('--app-top-space','" + px + "px');})()", null);
  }
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    // Draw edge-to-edge, then move the HTML app content below the real status bar.
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      getWindow().setDecorFitsSystemWindows(false);
    } else {
      getWindow().getDecorView().setSystemUiVisibility(0);
    }
    web = new WebView(this);
    int statusBarId = getResources().getIdentifier("status_bar_height", "dimen", "android");
    int fallbackStatusHeight = statusBarId > 0 ? getResources().getDimensionPixelSize(statusBarId) : (int) (28 * getResources().getDisplayMetrics().density + 0.5f);
    topPaddingPx = fallbackStatusHeight + (int) (24 * getResources().getDisplayMetrics().density + 0.5f);
    web.setBackgroundColor(0xFFF7F8FA);
    getWindow().getDecorView().setOnApplyWindowInsetsListener((view, insets) -> {
      int statusTop;
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        statusTop = insets.getInsets(WindowInsets.Type.statusBars()).top;
      } else {
        statusTop = insets.getSystemWindowInsetTop();
      }
      int extraGap = (int) (24 * getResources().getDisplayMetrics().density + 0.5f);
      topPaddingPx = statusTop + extraGap;
      applyTopSpacing();
      return insets;
    });
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    s.setDatabaseEnabled(true);
    s.setDefaultTextEncodingName("UTF-8");
    // Enable Android's native file picker for HTML file inputs (profile photo and backup restore).
    web.setWebChromeClient(new WebChromeClient() {
      @Override
      public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                       FileChooserParams params) {
        if (fileChooserCallback != null) {
          fileChooserCallback.onReceiveValue(null);
        }
        fileChooserCallback = callback;
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        String mime = "*/*";
        if (params != null && params.getAcceptTypes() != null) {
          for (String type : params.getAcceptTypes()) {
            if (type != null && !type.trim().isEmpty() && !type.startsWith(".")) {
              mime = type.trim();
              break;
            }
          }
        }
        pick.setType(mime);
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
          startActivityForResult(Intent.createChooser(pick, "ফাইল নির্বাচন করুন"), FILE_CHOOSER_REQUEST);
        } catch (android.content.ActivityNotFoundException e) {
          fileChooserCallback = null;
          callback.onReceiveValue(null);
          return false;
        }
        return true;
      }
    });
    web.setWebViewClient(new WebViewClient() {
      @Override public void onPageFinished(WebView view, String url) {
        applyTopSpacing();
      }
    });
    setContentView(web);
    web.requestApplyInsets();
    getWindow().getDecorView().requestApplyInsets();
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == FILE_CHOOSER_REQUEST) {
      if (fileChooserCallback != null) {
        Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
        fileChooserCallback.onReceiveValue(result);
        fileChooserCallback = null;
      }
    }
  }

  @Override public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
  }
}
