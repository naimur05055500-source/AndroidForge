package com.banglalink.rso06;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.view.WindowInsets;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  private WebView web;
  private int topPaddingPx = 0;

  private void applyTopSpacing() {
    if (web == null) return;
    final int px = topPaddingPx;
    web.evaluateJavascript("(function(){document.body.style.paddingTop='" + px + "px';document.documentElement.style.setProperty('--app-top-space','" + px + "px');})()", null);
  }
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    // Draw edge-to-edge, then move the HTML app content below the real status bar.
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      getWindow().setDecorFitsSystemWindows(false);
    } else {
      getWindow().getDecorView().setSystemUiVisibility(0);
    }
    web = new WebView(this);
    int statusBarId = getResources().getIdentifier("status_bar_height", "dimen", "android");
    int fallbackStatusHeight = statusBarId > 0 ? getResources().getDimensionPixelSize(statusBarId) : (int) (28 * getResources().getDisplayMetrics().density + 0.5f);
    topPaddingPx = fallbackStatusHeight + (int) (24 * getResources().getDisplayMetrics().density + 0.5f);
    web.setBackgroundColor(0xFFF7F8FA);
    getWindow().getDecorView().setOnApplyWindowInsetsListener((view, insets) -> {
      int statusTop;
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        statusTop = insets.getInsets(WindowInsets.Type.statusBars()).top;
      } else {
        statusTop = insets.getSystemWindowInsetTop();
      }
      int extraGap = (int) (24 * getResources().getDisplayMetrics().density + 0.5f);
      topPaddingPx = statusTop + extraGap;
      applyTopSpacing();
      return insets;
    });
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    s.setDatabaseEnabled(true);
    s.setDefaultTextEncodingName("UTF-8");
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient() {
      @Override public void onPageFinished(WebView view, String url) {
        applyTopSpacing();
      }
    });
    setContentView(web);
    web.requestApplyInsets();
    getWindow().getDecorView().requestApplyInsets();
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
  }
}
